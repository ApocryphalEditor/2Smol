# --- START OF analyze_batch_v9.0.py --- # <--- V9.0 Update
import torch
import matplotlib.pyplot as plt
import numpy as np
from transformer_lens import HookedTransformer
import os
import re
import math
from datetime import datetime
from numpy.linalg import norm # Explicitly import norm
import traceback # For detailed error printing
import argparse # For command-line arguments
from collections import defaultdict # For cluster color mapping
import heapq # For efficient Top K finding in neighbors
import warnings # To suppress specific warnings if needed

# --- Optional imports for Clustering ---
try:
    from sklearn.decomposition import PCA
    from sklearn.manifold import TSNE
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False

try:
    import umap
    UMAP_AVAILABLE = True
except ImportError:
    UMAP_AVAILABLE = False

# --- Configuration ---
DEVICE = "cpu"
BASE_OUTPUT_DIR = "analysis_outputs"
TIMESTAMP = datetime.now().strftime('%Y%m%d_%H%M%S')
# --- V9.0 Update Start ---
ANALYSIS_VERSION = "V9.0"
ANALYSIS_VERSION_DIR = f"analysis_{ANALYSIS_VERSION.lower().replace('.', '_')}_{TIMESTAMP}" # e.g., analysis_v9_0_YYYYMMDD_HHMMSS
SUMMARY_REPORT_FILENAME = f"summary_report_full_{ANALYSIS_VERSION.lower()}.txt"
SUMMARY_REPORT_BRIEF_FILENAME = f"summary_report_brief_{ANALYSIS_VERSION.lower()}.txt"
CLUSTER_PLOT_FILENAME = f"clusters_2d_{ANALYSIS_VERSION.lower()}.png"
DEFAULT_INPUT_FILENAME = "batch_input_v9.txt" # Assumes input file version matches script (though V8 input should work)
# --- V9.0 Update End ---
SAVE_INDIVIDUAL_HEATMAPS = False
COMPARISON_SUBDIR = "comparisons"
TOP_N = 10
DEFAULT_NEIGHBOR_METRIC = 'euclidean'
DEFAULT_ANALYSIS_LAYER = 'final' # Default layer if not specified ('final', 'all', or int)
N_LAYERS_GPT2_SMALL = 12 # Specific to gpt2-small, needed for default 'final' layer resolution

# --- V9.0 CDI Defaults ---
DEFAULT_CDI_WEIGHTS = [1.0, 1.0, 0.5]
DEFAULT_CDI_INCLUDE_VARIANCE = True
DEFAULT_CDI_VARIANCE_TYPE = 'cosine'
DEFAULT_CDI_NORMALIZATION = 'average'
DEFAULT_TOP_CDI_K = 20


# --- Command-line Arguments ---
# --- V9.0 Update Start ---
parser = argparse.ArgumentParser(description=f"Run activation analysis {ANALYSIS_VERSION} with layer-specific capabilities and Conceptual Drift Index (CDI).")
# --- V9.0 Update End ---
parser.add_argument('-i', '--input', default=DEFAULT_INPUT_FILENAME, help=f"Input filename defining experiments (default: {DEFAULT_INPUT_FILENAME})")
parser.add_argument('--visualize_clusters', action='store_true', help='Generate a 2D cluster visualization (uses final layer) using UMAP (preferred) or PCA+t-SNE.')
parser.add_argument('--save_heatmaps', action='store_true', help='Save individual activation heatmaps (can create many files).')
# --- V9.0 CDI Arguments ---
parser.add_argument('--calculate_cdi', action='store_true', help='Calculate the Conceptual Drift Index (CDI) for each result.')
parser.add_argument('--cdi_weights', nargs='+', type=float, default=DEFAULT_CDI_WEIGHTS, help=f'Weights for CDI components (Dir, Pos, [Var]). Default: {DEFAULT_CDI_WEIGHTS}')
parser.add_argument('--include_cdi_variance', action=argparse.BooleanOptionalAction, default=DEFAULT_CDI_INCLUDE_VARIANCE, help='Include variance term in CDI calculation.')
parser.add_argument('--cdi_variance_type', choices=['cosine', 'distance'], default=DEFAULT_CDI_VARIANCE_TYPE, help=f'Type of variance to include in CDI (default: {DEFAULT_CDI_VARIANCE_TYPE}).')
parser.add_argument('--cdi_normalization', choices=['average', 'sum'], default=DEFAULT_CDI_NORMALIZATION, help=f'Normalization for positional drift (default: {DEFAULT_CDI_NORMALIZATION}).')
parser.add_argument('--top_cdi_k', type=int, default=DEFAULT_TOP_CDI_K, help=f'Report the top K items with highest CDI (default: {DEFAULT_TOP_CDI_K}).')
# --- End V9.0 Args ---

args = parser.parse_args()
INPUT_FILENAME = args.input
SAVE_INDIVIDUAL_HEATMAPS = args.save_heatmaps

# --- V9.0 Argument Validation ---
if args.include_cdi_variance and len(args.cdi_weights) != 3:
    print(f"Warning: --include_cdi_variance is set, but {len(args.cdi_weights)} weights provided. Expected 3 (Dir, Pos, Var). Using default weights: {DEFAULT_CDI_WEIGHTS}")
    args.cdi_weights = DEFAULT_CDI_WEIGHTS
elif not args.include_cdi_variance and len(args.cdi_weights) != 2:
     # If variance excluded, allow 2 weights, but default has 3. We'll only use first 2.
     if len(args.cdi_weights) < 2:
        print(f"Warning: --no-include_cdi_variance is set, but {len(args.cdi_weights)} weights provided. Expected 2 (Dir, Pos). Using default weights [0:2]: {DEFAULT_CDI_WEIGHTS[:2]}")
        args.cdi_weights = DEFAULT_CDI_WEIGHTS[:2] # Use first two defaults
     # If more than 2 provided, just use the first 2 when variance excluded
     args.cdi_weights = args.cdi_weights[:2]


# --- Helper Functions ---
# [ sanitize_filename, parse_prompt_line, find_target_token_index ] - Identical to V8.0
def sanitize_filename(name):
    name = name.strip().lower(); name = re.sub(r'[^\w\-]+', '_', name); name = re.sub(r'_+', '_', name); name = name.strip('_')
    if not name: name = "untitled";
    max_len = 50; name = name[:max_len] if len(name) > max_len else name
    return name
def parse_prompt_line(line):
    match = re.match(r"^(.*?)\[([\w\s']+)\](.*)$", line.strip())
    if match: pre, target, post = match.group(1).strip(), match.group(2).strip(), match.group(3).strip(); prompt = f"{pre} {target} {post}".strip(); return prompt, target
    return None
def find_target_token_index(model, prompt, target_word):
    tokens = model.to_tokens(prompt, prepend_bos=True); str_tokens = model.to_str_tokens(tokens[0])
    target_indices = []; processed_target = target_word.strip().lower()
    for i, token_str in enumerate(str_tokens):
        processed_token = token_str.strip().lower()
        if token_str.startswith('Ġ') and token_str[1:].lower() == processed_target: target_indices.append(i)
        elif processed_token == processed_target: target_indices.append(i)
        elif processed_token.replace(' ','') == processed_target: target_indices.append(i)
    if target_indices:
        chosen_index = target_indices[-1]
        if chosen_index < len(str_tokens): return chosen_index, str_tokens[chosen_index]
        else: print(f"Error: Target index {chosen_index} out of bounds ({len(str_tokens)} tokens)."); return None, str_tokens
    print(f"Error: Could not find token index for '{target_word}' in '{prompt}'. Tokens: {str_tokens}"); return None, str_tokens

# [ calculate_cosine_similarity, calculate_euclidean_distance, get_top_n_neurons ] - Identical to V8.0
def calculate_cosine_similarity(vec1, vec2):
    vec1 = np.asarray(vec1); vec2 = np.asarray(vec2); norm1 = norm(vec1); norm2 = norm(vec2)
    # V9 Add check for NaN vectors before norm
    if np.isnan(vec1).any() or np.isnan(vec2).any(): return np.nan
    if norm1 == 0 or norm2 == 0: return 0.0 # Return 0 for zero vectors, not NaN
    similarity = np.dot(vec1, vec2) / (norm1 * norm2)
    return np.clip(similarity, -1.0, 1.0)
def calculate_euclidean_distance(vec1, vec2):
    vec1 = np.asarray(vec1); vec2 = np.asarray(vec2)
    if np.isnan(vec1).any() or np.isnan(vec2).any(): return np.nan # V9 Handle NaN input
    try: return norm(vec1 - vec2)
    except Exception as e: print(f"Error calculating Euclidean distance: {e}"); return np.nan
def get_top_n_neurons(vector, n):
    if not isinstance(vector, np.ndarray): vector = np.array(vector)
    if vector.size == 0: return ([], [])
    # V9 Handle NaN input vector
    if np.isnan(vector).all(): return ([], [])
    n = min(n, len(vector));
    if n <= 0: return ([], [])
    # Use nanpartition to handle potential NaNs robustly
    try:
        # Partition puts NaNs at the end, so this should work
        smallest_indices = np.argpartition(vector, n)[:n]
        largest_indices = np.argpartition(vector, -n)[-n:] # Negative indices count from end

        # Filter NaNs *after* partition and sort only the potential candidates
        top_negative = sorted([(i, vector[i]) for i in smallest_indices if not math.isnan(vector[i])], key=lambda x: x[1])
        top_positive = sorted([(i, vector[i]) for i in largest_indices if not math.isnan(vector[i])], key=lambda x: x[1], reverse=True)

        # Ensure we return exactly N items if available (partition might include fewer non-NaNs)
        return top_positive[:n], top_negative[:n]
    except Exception as e:
        print(f"Error in get_top_n_neurons: {e}")
        # Fallback: slower sort if partition fails unexpectedly
        valid_indices = np.where(~np.isnan(vector))[0]
        if not valid_indices.any(): return ([], [])
        sorted_indices = valid_indices[np.argsort(vector[valid_indices])]
        top_neg_idx = sorted_indices[:n]
        top_pos_idx = sorted_indices[-n:][::-1] # Sort descending
        top_positive = [(i, vector[i]) for i in top_pos_idx]
        top_negative = [(i, vector[i]) for i in top_neg_idx]
        return top_positive, top_negative

# [ parse_layer_spec ] - Identical to V8.0
def parse_layer_spec(spec_str):
    if spec_str is None: return DEFAULT_ANALYSIS_LAYER
    spec_str_upper = spec_str.upper()
    if spec_str_upper == 'ALL': return 'all'
    if spec_str_upper == 'FINAL': return 'final'
    match = re.match(r"L(\d+)", spec_str_upper)
    if match:
        layer_num = int(match.group(1))
        if 0 <= layer_num < N_LAYERS_GPT2_SMALL: return layer_num
        else: print(f"Warning: Invalid layer number {layer_num}. Must be 0-{N_LAYERS_GPT2_SMALL-1}."); return None
    print(f"Warning: Could not parse layer specification '{spec_str}'. Using default '{DEFAULT_ANALYSIS_LAYER}'.")
    return DEFAULT_ANALYSIS_LAYER

# [ parse_input_file ] - Identical to V8.0 (Parses V8/V9 syntax)
def parse_input_file(filename):
    experiments = []
    comparison_requests = []
    neighbor_requests = []
    vector_definitions = []
    arithmetic_requests = []
    apply_vector_requests = []
    prompt_line_counter = 0
    print(f"Reading input file: {filename}")
    try:
        with open(filename, 'r') as f:
            for file_line_num, line in enumerate(f, 1):
                original_line = line; line_stripped = line.strip();
                if not line_stripped: continue
                is_directive = False; line_no_comment = line_stripped.split('#', 1)[0].strip()

                if line_stripped.upper().startswith('NEIGHBORS '):
                    is_directive = True; parts = line_stripped.split('#', 1)[0].strip().split(); metric = DEFAULT_NEIGHBOR_METRIC; layer_spec_parsed = DEFAULT_ANALYSIS_LAYER
                    if len(parts) >= 4:
                        try:
                            idx = 1; word_key = parts[idx].lower(); idx += 1; eff_num = int(parts[idx]); idx += 1
                            maybe_layer_spec = parts[idx].upper()
                            if maybe_layer_spec.startswith('L') and maybe_layer_spec[1:].isdigit():
                                layer_spec_parsed = parse_layer_spec(maybe_layer_spec)
                                if layer_spec_parsed is None: raise ValueError(f"Invalid layer format {maybe_layer_spec}")
                                idx += 1
                            k = int(parts[idx]); idx += 1;
                            if k <= 0: raise ValueError("k must be positive")
                            if idx < len(parts) and parts[idx].lower().startswith("metric="):
                                metric_val = parts[idx].lower().split("=")[1]
                                if metric_val in ['euclidean', 'cosine']: metric = metric_val
                                else: print(f"Warning: Invalid metric '{metric_val}' on NEIGHBORS line {file_line_num}. Using default '{metric}'.")
                                idx += 1
                            if idx != len(parts): print(f"Warning: Extra arguments found on NEIGHBORS line {file_line_num}: '{' '.join(parts[idx:])}'. Ignoring.")
                            neighbor_requests.append({'original_line': file_line_num, 'word_key': word_key,'eff_num': eff_num, 'k': k, 'metric': metric, 'layer_spec': layer_spec_parsed })
                        except (ValueError, IndexError) as e: print(f"Warning: Invalid NEIGHBORS arguments on line {file_line_num}: '{original_line}'. Error: {e}. Skipping.")
                    else: print(f"Warning: Could not parse NEIGHBORS directive on line {file_line_num} (expected >= 4 parts): '{original_line}'. Skipping.")

                elif line_stripped.startswith('#'):
                    is_directive = True; directive_line_content = line_stripped[1:].strip();
                    if not directive_line_content: continue
                    command_part = directive_line_content.split('#', 1)[0].strip();
                    if not command_part: continue
                    parts = command_part.split();
                    if not parts: continue
                    directive_cmd = parts[0].upper(); directive = f"#{directive_cmd}"

                    if directive == '#COMPARE':
                        layer_spec_parsed = DEFAULT_ANALYSIS_LAYER; arg1_raw, arg2_raw = None, None; min_parts = 3; max_parts = 4
                        if len(parts) == min_parts: arg1_raw, arg2_raw = parts[1], parts[2]
                        elif len(parts) == max_parts:
                            maybe_layer_spec = parts[1].upper()
                            if maybe_layer_spec.startswith('L') or maybe_layer_spec == 'ALL':
                                layer_spec_parsed = parse_layer_spec(maybe_layer_spec)
                                if layer_spec_parsed is None: print(f"Warning: Invalid layer spec '{parts[1]}' in #COMPARE line {file_line_num}. Skipping."); continue
                                arg1_raw, arg2_raw = parts[2], parts[3]
                            else: print(f"Warning: Invalid format for #COMPARE line {file_line_num}. Expected '[L<layer>|ALL]' as first arg or omit. Line: '{original_line}'. Skipping."); continue
                        else: print(f"Warning: Invalid number of arguments ({len(parts)}) for #COMPARE on line {file_line_num}. Expected 3 or 4. Line: '{original_line}'. Skipping."); continue
                        # Arg validation (V7.7)
                        arg1_is_num, arg2_is_num = False, False; arg1_is_valid_concept, arg2_is_valid_concept = False, False
                        try: arg1_num = int(arg1_raw); arg1_is_num = True
                        except ValueError: arg1_num = None; arg1_concept = arg1_raw.lower(); arg1_is_valid_concept = bool(re.match(r'^[a-z][a-z0-9_-]*$', arg1_concept))
                        try: arg2_num = int(arg2_raw); arg2_is_num = True
                        except ValueError: arg2_num = None; arg2_concept = arg2_raw.lower(); arg2_is_valid_concept = bool(re.match(r'^[a-z][a-z0-9_-]*$', arg2_concept))
                        valid_combo = (arg1_is_num and arg2_is_num) or (arg1_is_num and arg2_is_valid_concept) or (arg1_is_valid_concept and arg2_is_num) or (arg1_is_valid_concept and arg2_is_valid_concept)
                        if not valid_combo: print(f"Warning: Skipping #COMPARE line {file_line_num}: Invalid argument format '{arg1_raw}' or '{arg2_raw}'. Expected numbers or concepts. Line: '{original_line}'"); continue
                        # Store request
                        request = {'original_line': file_line_num, 'layer_spec': layer_spec_parsed}
                        if arg1_is_num and arg2_is_num: request.update({'type': 'line_vs_line', 'line1': arg1_num, 'line2': arg2_num})
                        elif arg1_is_num and not arg2_is_num: request.update({'type': 'line_vs_concept', 'line': arg1_num, 'concept': arg2_concept})
                        elif not arg1_is_num and arg2_is_num: request.update({'type': 'line_vs_concept', 'line': arg2_num, 'concept': arg1_concept})
                        else: request.update({'type': 'concept_vs_concept', 'concept1': arg1_concept, 'concept2': arg2_concept})
                        comparison_requests.append(request)

                    elif directive == '#DEFINE_VEC' and len(parts) == 6 and parts[2] == '=':
                         layer_spec_raw = parts[5].upper(); layer_spec_parsed = parse_layer_spec(layer_spec_raw)
                         if not isinstance(layer_spec_parsed, int): print(f"Warning: Invalid/missing layer L<num> ('{layer_spec_raw}') in #DEFINE_VEC on line {file_line_num}. Mandatory. Skipping."); continue
                         vec_name = parts[1].lower(); concept_key = parts[3].lower()
                         try: eff_num = int(parts[4]); vector_definitions.append({'original_line': file_line_num, 'vec_name': vec_name, 'concept_key': concept_key, 'eff_num': eff_num, 'layer_spec': layer_spec_parsed})
                         except ValueError: print(f"Warning: Invalid eff# '{parts[4]}' in #DEFINE_VEC on line {file_line_num}: '{original_line}'. Skipping.")
                         except IndexError: print(f"Warning: Index error parsing #DEFINE_VEC on line {file_line_num}: '{original_line}'. Skipping.")

                    elif directive == '#ARITHMETIC' and len(parts) == 6 and parts[2] == '=':
                         result_name = parts[1].lower(); vec1_name = parts[3].lower(); op = parts[4]; vec2_name = parts[5].lower()
                         if op not in ['+', '-']: print(f"Warning: Invalid operator '{op}' in #ARITHMETIC line {file_line_num}. Use '+' or '-'. Skipping."); continue
                         arithmetic_requests.append({ 'original_line': file_line_num, 'result_name': result_name, 'vec1_name': vec1_name, 'op': op, 'vec2_name': vec2_name })

                    elif directive == '#APPLY_VEC' and len(parts) >= 7:
                         metric = DEFAULT_NEIGHBOR_METRIC; target_concept = parts[1].lower(); op = parts[4]; vec_name = parts[5].lower()
                         try:
                             target_eff_num = int(parts[2]); target_layer_raw = parts[3].upper(); target_layer_spec = parse_layer_spec(target_layer_raw)
                             if not isinstance(target_layer_spec, int): raise ValueError(f"Invalid/missing target layer L<num> ('{target_layer_raw}')")
                             k = int(parts[6]);
                             if k <= 0: raise ValueError("k must be positive")
                             if op not in ['+', '-']: raise ValueError(f"Invalid operator '{op}'. Use '+' or '-'.")
                             if len(parts) > 7 and parts[7].lower().startswith("metric="):
                                 metric_val = parts[7].lower().split("=")[1]
                                 if metric_val in ['euclidean', 'cosine']: metric = metric_val
                                 else: print(f"Warning: Invalid metric '{metric_val}' in #APPLY_VEC line {file_line_num}. Using default '{metric}'.")
                             apply_vector_requests.append({'original_line': file_line_num, 'target_concept': target_concept, 'target_eff_num': target_eff_num, 'op': op, 'vec_name': vec_name, 'k': k, 'metric': metric, 'layer_spec': target_layer_spec})
                         except (ValueError, IndexError) as e: print(f"Warning: Invalid arguments in #APPLY_VEC on line {file_line_num}: '{original_line}'. Error: {e}. Skipping.")

                if not is_directive:
                    parsed = parse_prompt_line(line_no_comment)
                    if parsed: prompt_line_counter += 1; experiments.append({ 'id': f"file_line_{file_line_num}", 'prompt': parsed[0], 'target_word': parsed[1], 'effective_prompt_num': prompt_line_counter })
                    elif line_stripped and not line_stripped.startswith('#'): print(f"Info: Skipping file line {file_line_num} as it's not a valid prompt or known directive: '{original_line}'")

    except FileNotFoundError: print(f"FATAL: Input file '{filename}' not found."); return None, None, None, None, None, None
    except Exception as e: print(f"FATAL: Error reading input file '{filename}': {e}"); traceback.print_exc(); return None, None, None, None, None, None

    print(f"\nParsed {len(experiments)} experiments (prompt lines).")
    print(f"Found {len(comparison_requests)} #COMPARE directives.")
    print(f"Found {len(neighbor_requests)} NEIGHBORS directives.")
    print(f"Found {len(vector_definitions)} #DEFINE_VEC directives.")
    print(f"Found {len(arithmetic_requests)} #ARITHMETIC directives.")
    print(f"Found {len(apply_vector_requests)} #APPLY_VEC directives.")
    if not experiments: print("Warning: No valid experiments found in input file.")
    return experiments, comparison_requests, neighbor_requests, vector_definitions, arithmetic_requests, apply_vector_requests


# --- Post-Processing Functions ---
# [ run_individual_concept_analysis, run_comparative_analysis ] - Identical to V8.0
def run_individual_concept_analysis(first_results_map, top_n, n_layers_model):
    print(f"\nCalculating Top {top_n} Neurons for each concept (Final Layer [L{n_layers_model-1}], First Instance)...")
    concept_top_neurons = {}; target_layer_index = n_layers_model - 1
    for key, result in first_results_map.items():
        all_activations = result.get('all_layer_activations')
        if all_activations is None or not isinstance(all_activations, np.ndarray) or all_activations.shape[0] != n_layers_model: print(f"  Warning: Missing/invalid activation data for '{key}'. Skipping Top N."); continue
        final_vector = all_activations[target_layer_index, :]
        if final_vector is None or len(final_vector) == 0: print(f"  Warning: Final layer vector empty for '{key}'. Skipping Top N."); continue
        try: top_pos, top_neg = get_top_n_neurons(final_vector, top_n); concept_top_neurons[key] = {'pos': top_pos, 'neg': top_neg}
        except Exception as e: print(f"  Error calculating Top N for '{key}' (Final Layer): {e}"); traceback.print_exc()
    return concept_top_neurons
def run_comparative_analysis(comparison_requests, results_data, comparison_output_dir, top_n, n_layers_model):
    print("\nPerforming Comparative Analysis (#COMPARE)...")
    if not comparison_requests: print("  No comparison requests found. Skipping."); return {}, {}, {}
    prompt_num_to_result = {res['effective_prompt_num']: res for res in results_data}
    concept_key_to_first_result = {res['target_word_key']: res for res in results_data[::-1]}
    comparison_results = {}; difference_analysis_outputs = {}; difference_top_neurons = {}
    comparisons_processed_count = 0; comparisons_skipped_count = 0

    for request in comparison_requests:
        req_type = request['type']; result1, result2 = None, None; key1_repr, key2_repr = "N/A", "N/A"
        layer_spec = request['layer_spec']
        target_layer_indices = []; layer_label_for_output = ""
        if layer_spec == 'final': target_layer_indices = [n_layers_model - 1]; layer_label_for_output = f"L{n_layers_model - 1} (Final)"
        elif layer_spec == 'all': target_layer_indices = list(range(n_layers_model)); layer_label_for_output = f"All Layers (L0-L{n_layers_model - 1})"
        elif isinstance(layer_spec, int):
            if 0 <= layer_spec < n_layers_model: target_layer_indices = [layer_spec]; layer_label_for_output = f"L{layer_spec}"
            else: print(f"  Warning: Invalid layer index {layer_spec} in comparison line {request['original_line']}. Skipping."); comparisons_skipped_count += 1; continue
        else: print(f"  Internal Warning: Unexpected layer_spec '{layer_spec}' in comparison line {request['original_line']}. Skipping."); comparisons_skipped_count += 1; continue

        try:
            warn_msg = ""; line_id_1, line_id_2 = "N/A", "N/A"
            if req_type == 'line_vs_line': line1, line2 = request['line1'], request['line2']; result1 = prompt_num_to_result.get(line1); result2 = prompt_num_to_result.get(line2); key1_repr, key2_repr = f"L{line1}", f"L{line2}"; line_id_1 = result1.get('id',f'L{line1}') if result1 else f'L{line1}_NF'; line_id_2 = result2.get('id',f'L{line2}') if result2 else f'L{line2}_NF'
            elif req_type == 'line_vs_concept': line, concept = request['line'], request['concept']; result1 = prompt_num_to_result.get(line); result2 = concept_key_to_first_result.get(concept); key1_repr, key2_repr = f"L{line}", f"'{concept}'(1st)"; line_id_1 = result1.get('id',f'L{line}') if result1 else f'L{line}_NF'; line_id_2 = result2.get('id',f'C_{concept}') if result2 else f'C_{concept}_NF'
            elif req_type == 'concept_vs_concept': concept1, concept2 = request['concept1'], request['concept2']; result1 = concept_key_to_first_result.get(concept1); result2 = concept_key_to_first_result.get(concept2); key1_repr, key2_repr = f"'{concept1}'(1st)", f"'{concept2}'(1st)"; line_id_1 = result1.get('id',f'C_{concept1}') if result1 else f'C_{concept1}_NF'; line_id_2 = result2.get('id',f'C_{concept2}') if result2 else f'C_{concept2}_NF'
            if not result1: warn_msg += f"No result for {key1_repr.split(' ')[0]} (ID:{line_id_1}) "
            if not result2: warn_msg += f"No result for {key2_repr.split(' ')[0]} (ID:{line_id_2}) "
            if warn_msg: print(f"  Warning: {warn_msg}in comparison line {request['original_line']}. Skipping."); comparison_key = (key1_repr, key2_repr, layer_spec); comparison_results[comparison_key] = None; comparisons_skipped_count += 1; continue
            activations1 = result1.get('all_layer_activations'); activations2 = result2.get('all_layer_activations')
            if activations1 is None or not isinstance(activations1, np.ndarray) or activations1.shape[0] != n_layers_model: warn_msg += f"Invalid activations {key1_repr} "
            if activations2 is None or not isinstance(activations2, np.ndarray) or activations2.shape[0] != n_layers_model: warn_msg += f"Invalid activations {key2_repr} "
            if warn_msg: print(f"  Warning: {warn_msg}in comparison line {request['original_line']}. Skipping."); comparison_key = (key1_repr, key2_repr, layer_spec); comparison_results[comparison_key] = None; comparisons_skipped_count += 1; continue

            comparison_key = (key1_repr, key2_repr, layer_spec); similarities = []; euclidean_distances = []
            for layer_idx in target_layer_indices:
                vec1 = activations1[layer_idx, :]; vec2 = activations2[layer_idx, :]
                sim = np.nan; euc = np.nan
                if vec1 is not None and vec2 is not None and isinstance(vec1, np.ndarray) and isinstance(vec2, np.ndarray):
                     try: sim = calculate_cosine_similarity(vec1, vec2)
                     except Exception as e: print(f"    Err cos L{layer_idx} {comparison_key}: {e}")
                     try: euc = calculate_euclidean_distance(vec1, vec2)
                     except Exception as e: print(f"    Err euc L{layer_idx} {comparison_key}: {e}")
                else: print(f"    Warn: Missing L{layer_idx} vecs {comparison_key}.")
                similarities.append(sim); euclidean_distances.append(euc)
            final_sim = similarities[0] if len(similarities) == 1 else similarities; final_euc = euclidean_distances[0] if len(euclidean_distances) == 1 else euclidean_distances
            comparison_results[comparison_key] = {'similarity': final_sim, 'euclidean_distance': final_euc, 'res1': result1, 'res2': result2, 'layer_label': layer_label_for_output}

            if len(target_layer_indices) == 1:
                 layer_idx_diff = target_layer_indices[0]; vec1_diff = activations1[layer_idx_diff, :]; vec2_diff = activations2[layer_idx_diff, :]; diff_vector = vec1_diff - vec2_diff
                 f_key1 = sanitize_filename(key1_repr.replace("'", "").replace("(1st)", "first").replace("L","line")); f_key2 = sanitize_filename(key2_repr.replace("'", "").replace("(1st)", "first").replace("L","line"))
                 diff_filename_base = f"diff_L{layer_idx_diff}_{f_key1}_minus_{f_key2}"; diff_npy_path = os.path.join(comparison_output_dir, f"{diff_filename_base}_vec.npy");
                 np.save(diff_npy_path, diff_vector);
                 difference_analysis_outputs[comparison_key] = {'diff_npy': diff_npy_path, 'layer_index': layer_idx_diff}
                 if np.isnan(diff_vector).any(): print(f"   Warn: NaNs in L{layer_idx_diff} diff vec {comparison_key}.")
                 top_pos_diff, top_neg_diff = get_top_n_neurons(diff_vector, top_n)
                 difference_top_neurons[comparison_key] = {'pos_diff': top_pos_diff, 'neg_diff': top_neg_diff, 'layer_index': layer_idx_diff}

            comparisons_processed_count += 1
        except Exception as diff_err: print(f"  Unexpected error during comparative analysis for {key1_repr} vs {key2_repr} (Layer: {layer_spec}, Line: {request['original_line']}): {diff_err}"); traceback.print_exc(); comparisons_skipped_count += 1; comparison_key = (key1_repr, key2_repr, layer_spec); comparison_results[comparison_key] = None

    print(f"Comparative analysis complete. Processed: {comparisons_processed_count}, Skipped/Errored: {comparisons_skipped_count}")
    return comparison_results, difference_analysis_outputs, difference_top_neurons

# [ find_neighbors_core, find_neighbors, find_neighbors_for_vector ] - Identical to V8.0
def find_neighbors_core(seed_vector, seed_id, results_data, k, metric, target_layer_index, n_layers_model):
    neighbors = [];
    if seed_vector is None or not isinstance(seed_vector, np.ndarray) or seed_vector.size == 0: print(f"  Warn: Invalid seed vec (L{target_layer_index}, ID:{seed_id}). Skip neighbors."); return []
    if not (0 <= target_layer_index < n_layers_model): print(f"  Err: Invalid target_layer {target_layer_index}. Skip neighbors."); return []
    for potential_neighbor in results_data:
        neighbor_id = potential_neighbor.get('id', 'Unknown')
        if seed_id is not None and neighbor_id == seed_id: continue
        neighbor_activations = potential_neighbor.get('all_layer_activations'); neighbor_eff_num = potential_neighbor.get('effective_prompt_num', 'N/A')
        if neighbor_activations is None or not isinstance(neighbor_activations, np.ndarray) or neighbor_activations.shape[0] != n_layers_model: continue
        neighbor_vector = neighbor_activations[target_layer_index, :]
        if neighbor_vector is None or not isinstance(neighbor_vector, np.ndarray) or neighbor_vector.size == 0: continue
        if neighbor_vector.shape != seed_vector.shape: print(f"  Warn: Shape mismatch seed ({seed_vector.shape}) vs L{neighbor_eff_num} ({neighbor_id}, {neighbor_vector.shape}) at L{target_layer_index}. Skipping."); continue
        distance = np.nan; similarity = np.nan
        try:
            if metric == 'euclidean':
                distance = calculate_euclidean_distance(seed_vector, neighbor_vector)
                if not math.isnan(distance): heap_item = (-distance, neighbor_id, potential_neighbor); heapq.heappush(neighbors, heap_item) if len(neighbors) < k else heapq.heappushpop(neighbors, heap_item)
            elif metric == 'cosine':
                similarity = calculate_cosine_similarity(seed_vector, neighbor_vector)
                if not math.isnan(similarity): heap_item = (similarity, neighbor_id, potential_neighbor); heapq.heappush(neighbors, heap_item) if len(neighbors) < k else heapq.heappushpop(neighbors, heap_item)
        except Exception as e: print(f"  Err calc metric L{neighbor_eff_num} ({neighbor_id}) L{target_layer_index}: {e}")
    final_neighbors = [];
    while neighbors: value, _, neighbor_info = heapq.heappop(neighbors); actual_metric_value = -value if metric == 'euclidean' else value; final_neighbors.append((neighbor_info, actual_metric_value))
    sort_reverse = (metric == 'cosine'); final_neighbors.sort(key=lambda x: x[1], reverse=sort_reverse)
    return final_neighbors[:k]
def find_neighbors(seed_word_key, seed_eff_num, results_data, k, metric, layer_spec, n_layers_model):
    target_layer_index = -1
    if layer_spec == 'final': target_layer_index = n_layers_model - 1
    elif isinstance(layer_spec, int) and 0 <= layer_spec < n_layers_model: target_layer_index = layer_spec
    else: print(f"  Err: Invalid layer_spec '{layer_spec}' for neighbor search. Skip."); return None
    seed_result = None
    for res in results_data:
        if res.get('target_word_key') == seed_word_key and res.get('effective_prompt_num') == seed_eff_num: seed_result = res; break
    if not seed_result: print(f"  Err: No seed result '{seed_word_key}' (L{seed_eff_num}). Skip neighbors."); return None
    seed_activations = seed_result.get('all_layer_activations')
    if seed_activations is None or not isinstance(seed_activations, np.ndarray) or seed_activations.shape[0] != n_layers_model: print(f"  Err: Invalid activations seed '{seed_word_key}' (L{seed_eff_num}). Skip neighbors."); return None
    seed_vector = seed_activations[target_layer_index, :]; seed_id = seed_result['id']
    if seed_vector is None: print(f"  Err: Seed vector L{target_layer_index} is None for '{seed_word_key}' (L{seed_eff_num}). Skip."); return None
    return find_neighbors_core(seed_vector, seed_id, results_data, k, metric, target_layer_index, n_layers_model)
def find_neighbors_for_vector(seed_vector, description, results_data, k, metric, target_layer_index, n_layers_model):
    print(f"\nFinding Top {k} Neighbors for vector '{description}' (at Layer {target_layer_index}) using {metric}...")
    if seed_vector is None: print(f"  Err: Provided seed vector '{description}' None. Skip neighbors."); return None
    if not (0 <= target_layer_index < n_layers_model): print(f"  Err: Invalid target layer {target_layer_index}. Skip neighbors."); return None
    neighbors_list = find_neighbors_core(seed_vector, None, results_data, k, metric, target_layer_index, n_layers_model)
    print(f"  Found {len(neighbors_list)} neighbors for vector '{description}' (compared at L{target_layer_index}).")
    return neighbors_list

# [ run_vector_arithmetic ] - Identical to V8.0
def run_vector_arithmetic(vector_definitions_parsed, arithmetic_requests, apply_vector_requests,
                           results_data, results_by_num, results_by_concept_first, n_layers_model):
    print("\n--- Running Vector Arithmetic Processing ---")
    defined_vectors = {}; arithmetic_results = {}; apply_vector_results = {}
    print("\nProcessing #DEFINE_VEC directives...")
    if not vector_definitions_parsed: print("  No #DEFINE_VEC directives parsed.")
    else:
        definitions_processed = 0; definitions_skipped = 0
        for req in vector_definitions_parsed:
            name, concept, eff_num = req['vec_name'], req['concept_key'], req['eff_num']; layer_spec = req['layer_spec']
            source_str = f"'{concept}' (L{eff_num}, Layer {layer_spec})"; source_result = None
            if eff_num in results_by_num and results_by_num[eff_num].get('target_word_key') == concept: source_result = results_by_num[eff_num]
            else:
                 for res in results_data:
                    if res.get('target_word_key') == concept and res.get('effective_prompt_num') == eff_num: source_result = res; break
            if source_result:
                 source_activations = source_result.get('all_layer_activations')
                 if source_activations is not None and isinstance(source_activations, np.ndarray) and source_activations.shape[0] == n_layers_model:
                     vec = source_activations[layer_spec, :]
                     if vec is not None and isinstance(vec, np.ndarray): defined_vectors[name] = {'vector': vec.copy(), 'source': source_str, 'layer': layer_spec}; definitions_processed += 1
                     else: print(f"    Warn: Src vec L{layer_spec} for {source_str} (ID:{source_result.get('id')}) invalid. Skip def '{name}'. L:{req['original_line']}"); definitions_skipped += 1
                 else: print(f"    Warn: Invalid activation data src {source_str} (ID:{source_result.get('id')}). Skip def '{name}'. L:{req['original_line']}"); definitions_skipped += 1
            else: print(f"    Warn: No src result {source_str} (L:{req['original_line']}). Skip def '{name}'."); definitions_skipped += 1
        print(f"  Finished #DEFINE_VEC. Defined: {definitions_processed}, Skipped: {definitions_skipped}")

    print("\nProcessing #ARITHMETIC directives...")
    if not arithmetic_requests: print("  No #ARITHMETIC directives found.")
    else:
        arithmetic_processed = 0; arithmetic_skipped = 0
        for req in arithmetic_requests:
            res_name, v1_name, op, v2_name = req['result_name'], req['vec1_name'], req['op'], req['vec2_name']; formula_str = f"{v1_name} {op} {v2_name}"
            vec1_info = defined_vectors.get(v1_name) or arithmetic_results.get(v1_name); vec2_info = defined_vectors.get(v2_name) or arithmetic_results.get(v2_name);
            if vec1_info is None: print(f"    Warn: Vec '{v1_name}' undef/calc. Skip '{res_name}'. L:{req['original_line']}"); arithmetic_skipped += 1; continue
            if vec2_info is None: print(f"    Warn: Vec '{v2_name}' undef/calc. Skip '{res_name}'. L:{req['original_line']}"); arithmetic_skipped += 1; continue
            vec1 = vec1_info.get('vector'); layer1 = vec1_info.get('layer'); vec2 = vec2_info.get('vector'); layer2 = vec2_info.get('layer')
            if vec1 is None or layer1 is None: print(f"    Warn: Invalid data '{v1_name}'. Skip '{res_name}'."); arithmetic_skipped += 1; continue
            if vec2 is None or layer2 is None: print(f"    Warn: Invalid data '{v2_name}'. Skip '{res_name}'."); arithmetic_skipped += 1; continue
            if layer1 != layer2: print(f"    Warn: L mismatch #ARITH '{res_name}'. '{v1_name}' L{layer1}, '{v2_name}' L{layer2}. Skip. L:{req['original_line']}"); arithmetic_skipped += 1; continue
            op_layer = layer1
            try:
                vec1 = np.asarray(vec1); vec2 = np.asarray(vec2)
                if vec1.shape != vec2.shape: print(f"    Warn: Shape mismatch {v1_name} ({vec1.shape}) vs {v2_name} ({vec2.shape}) L{op_layer}. Skip '{res_name}'."); arithmetic_skipped += 1; continue
                result_vector = vec1 + vec2 if op == '+' else vec1 - vec2
                arithmetic_results[res_name] = {'vector': result_vector, 'formula': formula_str, 'layer': op_layer}
                print(f"    Calculated '{res_name}' (L{op_layer}). Norm: {norm(result_vector):.4f}"); arithmetic_processed += 1
            except Exception as e: print(f"    Err arithmetic '{res_name}' (L{op_layer}): {e}. Skip."); arithmetic_skipped += 1; traceback.print_exc()
        print(f"  Finished #ARITHMETIC. Calculated: {arithmetic_processed}, Skipped: {arithmetic_skipped}")

    print("\nProcessing #APPLY_VEC directives...")
    if not apply_vector_requests: print("  No #APPLY_VEC directives found.")
    else:
        apply_processed = 0; apply_skipped = 0
        for req in apply_vector_requests:
            target_concept, target_eff_num = req['target_concept'], req['target_eff_num']; op, vec_name = req['op'], req['vec_name']; k, metric = req['k'], req['metric']
            target_layer = req['layer_spec']
            request_key = (target_concept, target_eff_num, target_layer, op, vec_name, k, metric, req['original_line'])
            target_str = f"'{target_concept}' (L{target_eff_num}, Layer {target_layer})"; description = f"{target_str} {op} {vec_name}"
            target_result = None
            if target_eff_num in results_by_num and results_by_num[target_eff_num].get('target_word_key') == target_concept: target_result = results_by_num[target_eff_num]
            else:
                 for res in results_data:
                    if res.get('target_word_key') == target_concept and res.get('effective_prompt_num') == target_eff_num: target_result = res; break
            target_vector = None
            if target_result:
                target_activations = target_result.get('all_layer_activations')
                if target_activations is not None and isinstance(target_activations, np.ndarray) and target_activations.shape[0] == n_layers_model:
                    target_vector = target_activations[target_layer, :]
                    if target_vector is None or not isinstance(target_vector, np.ndarray): print(f"    Warn: Invalid target vec L{target_layer} for {target_str}. Skip Apply {description}."); target_vector = None
                else: print(f"    Warn: Invalid activation data target {target_str}. Skip Apply {description}.")
            else: print(f"    Warn: No target result {target_str}. Skip Apply {description}.")
            if target_vector is None: apply_vector_results[request_key] = None; apply_skipped += 1; continue
            target_vector = np.asarray(target_vector)
            operand_vector_info = defined_vectors.get(vec_name) or arithmetic_results.get(vec_name); operand_vector = None; operand_layer = None
            if operand_vector_info: operand_vector = operand_vector_info.get('vector'); operand_layer = operand_vector_info.get('layer')
            if operand_vector is None or operand_layer is None: print(f"    Warn: Operand vec '{vec_name}' undef/calc. Skip Apply {description}."); apply_vector_results[request_key] = None; apply_skipped += 1; continue
            if target_layer != operand_layer: print(f"    Warn: L mismatch #APPLY_VEC '{description}'. Target L{target_layer}, Op '{vec_name}' L{operand_layer}. Skip. L:{req['original_line']}"); apply_vector_results[request_key] = None; apply_skipped += 1; continue
            op_layer = target_layer; operand_vector = np.asarray(operand_vector)
            try:
                if target_vector.shape != operand_vector.shape: print(f"    Warn: Shape mismatch target {target_str} ({target_vector.shape}) vs op {vec_name} ({operand_vector.shape}) L{op_layer}. Skip Apply."); apply_vector_results[request_key] = None; apply_skipped += 1; continue
                calculated_vector = target_vector + operand_vector if op == '+' else target_vector - operand_vector
                neighbors_list = find_neighbors_for_vector(calculated_vector, description, results_data, k, metric, op_layer, n_layers_model)
                apply_vector_results[request_key] = neighbors_list; apply_processed += 1
            except Exception as e: print(f"    Err apply vec op '{description}' (L{op_layer}): {e}. Skip."); apply_vector_results[request_key] = None; apply_skipped += 1; traceback.print_exc()
        print(f"  Finished #APPLY_VEC. Searches: {apply_processed}, Skipped: {apply_skipped}")
    print("\nVector arithmetic processing complete.")
    return defined_vectors, arithmetic_results, apply_vector_results


# --- V9.0 New Function: Calculate Conceptual Drift Index (CDI) ---
def calculate_cdi(all_layer_activations, cdi_weights, include_variance, variance_type, normalization, n_layers_model):
    """
    Calculates the Conceptual Drift Index (CDI) and its components.
    """
    cdi_results = {
        'cdi_score': np.nan, 'drift_direction': np.nan, 'drift_position_norm': np.nan,
        'variance_term': np.nan, 'error': None
    }
    try:
        if all_layer_activations is None or not isinstance(all_layer_activations, np.ndarray) or all_layer_activations.shape != (n_layers_model, all_layer_activations.shape[1]):
            raise ValueError(f"Invalid activation shape: Expected ({n_layers_model}, D), got {all_layer_activations.shape if all_layer_activations is not None else 'None'}")
        if n_layers_model < 2:
             raise ValueError("CDI requires at least 2 layers.")

        # Check for NaNs in input
        if np.isnan(all_layer_activations).any():
             print("  Warning: NaNs found in activation data, CDI results may be NaN.")
             # Attempt calculation, relying on nan-aware numpy functions

        final_vector = all_layer_activations[-1, :]
        if np.isnan(final_vector).all():
             raise ValueError("Final layer vector is all NaNs.")

        # 1. Cosine Similarities to Final Layer
        cosine_similarities = [calculate_cosine_similarity(all_layer_activations[i, :], final_vector) for i in range(n_layers_model)]

        # 2. Consecutive Euclidean Distances
        euclidean_distances = [calculate_euclidean_distance(all_layer_activations[i, :], all_layer_activations[i+1, :]) for i in range(n_layers_model - 1)]

        # Calculate Components (using nan-aware functions)
        with warnings.catch_warnings(): # Suppress "Mean of empty slice" runtime warnings if all sims/dists are NaN
            warnings.simplefilter("ignore", category=RuntimeWarning)
            cdi_results['drift_direction'] = 1.0 - np.nanmean(cosine_similarities)

            drift_position_raw = np.nansum(euclidean_distances)
            if normalization == 'average':
                num_distances = len(euclidean_distances)
                cdi_results['drift_position_norm'] = drift_position_raw / num_distances if num_distances > 0 else 0.0
            else: # sum
                cdi_results['drift_position_norm'] = drift_position_raw

            variance_value = np.nan
            if include_variance:
                if variance_type == 'cosine':
                    variance_value = np.nanstd(cosine_similarities)
                elif variance_type == 'distance':
                    variance_value = np.nanstd(euclidean_distances)
            cdi_results['variance_term'] = variance_value if include_variance else 0.0 # Store NaN if included but failed, 0 if excluded

        # Calculate Final CDI Score
        w1 = cdi_weights[0]
        w2 = cdi_weights[1]
        w3 = cdi_weights[2] if include_variance and len(cdi_weights) > 2 else 0.0

        cdi_score = (w1 * cdi_results['drift_direction'] +
                     w2 * cdi_results['drift_position_norm'] +
                     (w3 * cdi_results['variance_term'] if include_variance and not np.isnan(cdi_results['variance_term']) else 0.0) )

        # Handle case where all components might be NaN
        if np.isnan(cdi_score):
            # If score is NaN, check if components were NaN too
             if np.isnan(cdi_results['drift_direction']) and np.isnan(cdi_results['drift_position_norm']) and (not include_variance or np.isnan(cdi_results['variance_term'])):
                 print("  Note: CDI score is NaN because all components were NaN (likely due to NaN activations).")
             else:
                 print("  Warning: CDI score calculated as NaN. Check component values.")
        cdi_results['cdi_score'] = cdi_score


    except ValueError as ve:
        cdi_results['error'] = f"ValueError: {ve}"
    except Exception as e:
        cdi_results['error'] = f"Unexpected Error: {e}"
        # print(f"  Error calculating CDI: {e}"); traceback.print_exc() # Optional detailed traceback

    return cdi_results

# --- V9.0 New Function: Run CDI Analysis Post-Processing Step ---
def run_cdi_analysis(results_data, args, n_layers_model):
    """ Calculates CDI for all results if requested via CLI args. """
    if not args.calculate_cdi:
        print("\nConceptual Drift Index (CDI) calculation skipped (use --calculate_cdi).")
        return results_data # Return unmodified data

    print(f"\n--- Calculating Conceptual Drift Index (CDI) ---")
    print(f"Settings: Weights={args.cdi_weights}, Include Variance={args.include_cdi_variance}, "
          f"Variance Type='{args.cdi_variance_type}', Normalization='{args.cdi_normalization}'")

    cdi_calculated_count = 0
    cdi_error_count = 0

    for i, result in enumerate(results_data):
        print(f"  Calculating CDI for result {i+1}/{len(results_data)} ('{result.get('target_word_key')}' L{result.get('effective_prompt_num')})...", end='\r')
        activations = result.get('all_layer_activations')

        if activations is None:
             cdi_data = {'error': 'Missing activation data'}
             cdi_error_count += 1
        else:
            cdi_data = calculate_cdi(
                activations,
                args.cdi_weights,
                args.include_cdi_variance,
                args.cdi_variance_type,
                args.cdi_normalization,
                n_layers_model
            )
            if cdi_data.get('error'):
                cdi_error_count += 1
                print(f"\n  Error calculating CDI for '{result.get('target_word_key')}' L{result.get('effective_prompt_num')}: {cdi_data['error']}")
            else:
                cdi_calculated_count += 1

        # Store CDI results in the main results dictionary
        result['cdi_results'] = cdi_data

    print(f"\nCDI Calculation Complete. Calculated: {cdi_calculated_count}, Errors: {cdi_error_count}")
    return results_data


# --- Report Generation Function (V9.0 Update - CDI Section) ---
def generate_summary_report(report_path, level, timestamp, input_filename, main_output_dir,
                            results_data, experiments, skipped_experiments, unique_concepts,
                            comparison_requests, neighbor_requests, vector_definitions_parsed, arithmetic_requests, apply_vector_requests,
                            concept_top_neurons, comparison_results, neighbor_results,
                            defined_vectors, arithmetic_results_data, apply_vector_results,
                            difference_analysis_outputs, difference_top_neurons,
                            comparison_output_dir, top_n, n_layers_model,
                            args): # V9.0 Added args for CDI settings
    report_type = "Full" if level == 'full' else "Brief"
    print(f"\nGenerating {report_type} summary report: {report_path}")
    num_processed = len(results_data); num_defined = len(experiments)
    try:
        with open(report_path, 'w') as f:
            f.write("="*50 + "\n"); f.write(f"          Analysis Summary Report ({ANALYSIS_VERSION} - {report_type})\n"); f.write("="*50 + "\n\n") # V9.0 Update
            f.write(f"Timestamp: {timestamp}\n"); f.write(f"Input File: {input_filename}\n")
            if level == 'full': f.write(f"Analysis Directory: {main_output_dir}\n")
            f.write(f"Model Layers: {n_layers_model}\n")
            f.write(f"Total Experiments Defined (Prompts): {num_defined}\n"); f.write(f"Successfully Processed (Activations Saved): {num_processed}\n")
            f.write(f"Skipped Experiments (Tokenization/Processing Error): {len(skipped_experiments)}\n"); f.write(f"Unique Concepts Found (Processed): {len(unique_concepts)}\n\n")
            f.write(f"Directives Parsed (from input file):\n"); f.write(f"  #COMPARE: {len(comparison_requests)}\n"); f.write(f"  NEIGHBORS: {len(neighbor_requests)}\n")
            f.write(f"  #DEFINE_VEC: {len(vector_definitions_parsed)}\n"); f.write(f"  #ARITHMETIC: {len(arithmetic_requests)}\n"); f.write(f"  #APPLY_VEC: {len(apply_vector_requests)}\n\n")
            # V9.0 Report CDI Status
            f.write(f"Conceptual Drift Index (CDI) Calculated: {'Yes' if args.calculate_cdi else 'No'}\n")
            if args.calculate_cdi:
                 f.write(f"  CDI Settings: Weights={args.cdi_weights}, VarIncluded={args.include_cdi_variance}, "
                       f"VarType='{args.cdi_variance_type}', Norm='{args.cdi_normalization}'\n")
                 f.write(f"  Top K Reported: {args.top_cdi_k}\n")
            f.write("\n")


            # --- Skipped Experiments Section ---
            # [ Identical to V8.0 ]
            if skipped_experiments:
                f.write("-" * 30 + "\n"); f.write(" Skipped Experiments (During Activation Extraction)\n"); f.write("-" * 30 + "\n\n")
                for skipped in skipped_experiments: f.write(f"ID: {skipped.get('id','N/A')} (Eff#: {skipped.get('effective_prompt_num','N/A')}) Target: '{skipped.get('target_word','N/A')}' Reason: {skipped.get('reason','Unknown')}\n"); f.write(f"  Details: {skipped['details']}\n") if level=='full' and 'details' in skipped else None; f.write("\n")
                f.write("\n")

            # --- Top N Neurons Section (Final Layer Only - Full Report Only) ---
            # [ Identical to V8.0 ]
            if level == 'full':
                f.write("-" * 50 + "\n"); f.write(f" Top {top_n} Activating Neurons (Final Layer L{n_layers_model-1}, First Instance)\n"); f.write("-" * 50 + "\n\n")
                if not concept_top_neurons: f.write("No Top N concept data generated (Final Layer).\n\n")
                else:
                    for concept in sorted(unique_concepts):
                         data = concept_top_neurons.get(concept); f.write(f"Concept: '{concept}'\n")
                         if data: f.write(f"  Top {top_n} Positive (Idx: Val):\n"); [f.write(f"    {idx}: {val:.4f}\n") for idx, val in data['pos']]; f.write(f"  Top {top_n} Negative (Idx: Val):\n"); [f.write(f"    {idx}: {val:.4f}\n") for idx, val in data['neg']]
                         else: f.write(f"  - Top N data not available.\n")
                         f.write("\n")
                f.write("\n")

            # --- Comparative Analysis Section ---
            # [ Identical to V8.0, reports layer-specific results ]
            f.write("-" * (50 if level=='full' else 30) + "\n"); f.write(f" Comparative Analysis Results (#COMPARE directives)\n"); f.write("-" * (50 if level=='full' else 30) + "\n\n")
            if not comparison_requests: f.write("No #COMPARE directives found or processed.\n\n")
            else:
                processed_comparisons_reported = 0; skipped_comparisons_reporting = 0
                for request in comparison_requests:
                     req_type = request['type']; key1_repr, key2_repr = "N/A", "N/A"; layer_spec = request['layer_spec']
                     if req_type == 'line_vs_line': key1_repr, key2_repr = f"L{request['line1']}", f"L{request['line2']}"
                     elif req_type == 'line_vs_concept': key1_repr, key2_repr = f"L{request['line']}", f"'{request['concept']}'(1st)"
                     elif req_type == 'concept_vs_concept': key1_repr, key2_repr = f"'{request['concept1']}'(1st)", f"'{request['concept2']}'(1st)"
                     else: continue
                     comparison_key = (key1_repr, key2_repr, layer_spec); result_data = comparison_results.get(comparison_key)
                     layer_label = result_data.get('layer_label', str(layer_spec)) if result_data else str(layer_spec)
                     f.write(f"Compare: {key1_repr} vs {key2_repr} (Layer: {layer_label}, Directive Line: {request['original_line']})\n")
                     if result_data is None: f.write("  - Result: Skipped (Data unavailable or error - check logs)\n\n"); skipped_comparisons_reporting +=1; continue
                     processed_comparisons_reported += 1; sim_result = result_data.get('similarity', np.nan); euc_result = result_data.get('euclidean_distance', np.nan)
                     if isinstance(sim_result, list): f.write(f"  - Cosine Sim (L0-L{n_layers_model-1}):\n    [{', '.join([f'{s:.3f}' if not math.isnan(s) else 'NaN' for s in sim_result])}]\n")
                     else: f.write(f"  - Cosine Similarity: {sim_result:.4f}\n")
                     if isinstance(euc_result, list): f.write(f"  - Euclidean Dist (L0-L{n_layers_model-1}):\n    [{', '.join([f'{d:.3f}' if not math.isnan(d) else 'NaN' for d in euc_result])}]\n")
                     else: f.write(f"  - Euclidean Distance: {euc_result:.4f}\n")
                     if level == 'full':
                         res1 = result_data.get('res1'); res2 = result_data.get('res2')
                         if res1: f.write(f"    (Item 1: {key1_repr} | Conc: '{res1.get('target_word_key')}' ID: {res1.get('id','N/A')} Eff#: {res1.get('effective_prompt_num','N/A')})\n")
                         else: f.write(f"    (Item 1: {key1_repr} | Data Missing)\n")
                         if res2: f.write(f"    (Item 2: {key2_repr} | Conc: '{res2.get('target_word_key')}' ID: {res2.get('id','N/A')} Eff#: {res2.get('effective_prompt_num','N/A')})\n")
                         else: f.write(f"    (Item 2: {key2_repr} | Data Missing)\n")
                     diff_files = difference_analysis_outputs.get(comparison_key); diff_neurons = difference_top_neurons.get(comparison_key)
                     if isinstance(layer_spec, int):
                         if diff_files and 'diff_npy' in diff_files: f.write(f"  - Diff Vector (L{diff_files['layer_index']}): Saved ({os.path.basename(diff_files['diff_npy'])})\n")
                         else: f.write(f"  - Difference Analysis (L{layer_spec}): Not Generated or Error\n")
                         if diff_neurons:
                             pos_diff_str = ", ".join([f"{idx}:{val:.2f}" for idx, val in diff_neurons.get('pos_diff', [])]); neg_diff_str = ", ".join([f"{idx}:{val:.2f}" for idx, val in diff_neurons.get('neg_diff', [])])
                             f.write(f"  Top {top_n} Diff Neurons (L{diff_neurons['layer_index']}, {key1_repr} > {key2_repr}):\n    {pos_diff_str if pos_diff_str else '(None)'}\n"); f.write(f"  Top {top_n} Diff Neurons (L{diff_neurons['layer_index']}, {key1_repr} < {key2_repr}):\n    {neg_diff_str if neg_diff_str else '(None)'}\n")
                         elif diff_files: f.write(f"  - Top N Difference Neurons (L{layer_spec}): Not Calculated or Error\n")
                     elif layer_spec == 'all': f.write(f"  - Difference Analysis: Not performed for 'ALL' layers.\n")
                     f.write("\n")
                f.write(f"Total Comparisons Reported: {processed_comparisons_reported}\n"); f.write(f"Total Comparisons Skipped: {skipped_comparisons_reporting}\n") if skipped_comparisons_reporting > 0 else None; f.write("\n")

            # --- Neighborhood Analysis Section ---
            # [ Identical to V8.0, reports layer-specific results ]
            f.write("-" * (50 if level=='full' else 30) + "\n"); f.write(f" Neighborhood Analysis Results (NEIGHBORS directives)\n"); f.write("-" * (50 if level=='full' else 30) + "\n\n")
            if not neighbor_requests: f.write("No NEIGHBORS directives found or processed.\n\n")
            elif not neighbor_results: f.write("Neighbor analysis requested but no results generated.\n\n")
            else:
                processed_neighbor_requests = 0; skipped_neighbor_requests = 0
                for request in neighbor_requests:
                    layer_spec = request['layer_spec']; layer_label = f"L{n_layers_model-1} (Final)" if layer_spec == 'final' else f"L{layer_spec}" if isinstance(layer_spec, int) else str(layer_spec)
                    req_key = (request['word_key'], request['eff_num'], request['k'], request['metric'], layer_spec); result_list = neighbor_results.get(req_key)
                    metric_used = request['metric']; dist_label = "Cosine Sim" if metric_used == 'cosine' else "Euclidean Dist"
                    f.write(f"Neighbors for '{request['word_key']}' (L{request['eff_num']}) - Top {request['k']} by {metric_used} at Layer {layer_label} (Directive Line: {request['original_line']}):\n")
                    if result_list is None: f.write("  - Result: Skipped (Seed not found or error - check logs)\n\n"); skipped_neighbor_requests += 1; continue
                    processed_neighbor_requests += 1
                    if not result_list: f.write(f"  - No neighbors found (excluding self) at Layer {layer_label}.\n\n"); continue
                    for neighbor_info, distance_or_sim in result_list: n_key = neighbor_info.get('target_word_key', 'N/A'); n_eff_num = neighbor_info.get('effective_prompt_num', 'N/A'); n_id = neighbor_info.get('id', 'N/A'); f.write(f"  - Neighbor: '{n_key}' (L{n_eff_num}) | {dist_label}: {distance_or_sim:.4f}"); f.write(f" | File ID: {n_id}\n") if level == 'full' else f.write("\n")
                    f.write("\n")
                f.write(f"Total Neighbor Analyses Processed: {processed_neighbor_requests}\n"); f.write(f"Total Neighbor Analyses Skipped: {skipped_neighbor_requests}\n") if skipped_neighbor_requests > 0 else None; f.write("\n")

            # --- Vector Definition & Arithmetic Section ---
            # [ Identical to V8.0, reports layer-specific results ]
            f.write("-" * (50 if level=='full' else 30) + "\n"); f.write(f" Vector Definition & Arithmetic Results\n"); f.write("-" * (50 if level=='full' else 30) + "\n\n")
            f.write(f"Defined Vectors (#DEFINE_VEC Results - Layer Mandatory):\n"); num_defs_parsed = len(vector_definitions_parsed); num_defs_succeeded = len(defined_vectors)
            if num_defs_parsed == 0: f.write("  No #DEFINE_VEC directives parsed.\n")
            elif num_defs_succeeded == 0: f.write(f"  No vectors successfully defined (all {num_defs_parsed} failed - check logs).\n")
            else:
                for name, data in sorted(defined_vectors.items()): vec_norm = norm(data['vector']) if data.get('vector') is not None else np.nan; f.write(f"  - '{name}': Defined from {data['source']} | Layer: {data['layer']} | Norm: {vec_norm:.4f}\n")
                if num_defs_succeeded < num_defs_parsed: f.write(f"  (Note: {num_defs_parsed - num_defs_succeeded} / {num_defs_parsed} #DEFINE_VEC directives failed)\n")
            f.write("\n")
            f.write(f"Arithmetic Results (#ARITHMETIC Results - Layer Consistency Enforced):\n"); num_arith_requested = len(arithmetic_requests); num_arith_succeeded = len(arithmetic_results_data)
            if num_arith_requested == 0: f.write("  No #ARITHMETIC directives parsed.\n")
            elif num_arith_succeeded == 0: f.write(f"  No arithmetic ops successfully performed (all {num_arith_requested} failed - check logs).\n")
            else:
                for name, data in sorted(arithmetic_results_data.items()): vec_norm = norm(data['vector']) if data.get('vector') is not None else np.nan; f.write(f"  - '{name}': Calculated = {data['formula']} | Layer: {data['layer']} | Norm: {vec_norm:.4f}\n")
                if num_arith_succeeded < num_arith_requested: f.write(f"  (Note: {num_arith_requested - num_arith_succeeded} / {num_arith_requested} #ARITHMETIC directives failed)\n")
            f.write("\n")
            f.write(f"Applied Vector Neighborhood Results (#APPLY_VEC directives - Layer Mandatory):\n"); num_apply_requested = len(apply_vector_requests); num_apply_succeeded_with_neighbors = len([res for res in apply_vector_results.values() if res is not None]); num_apply_attempted_processing = len(apply_vector_results)
            if num_apply_requested == 0: f.write("No #APPLY_VEC directives parsed.\n\n")
            elif num_apply_attempted_processing > 0:
                processed_apply_reported = 0; skipped_apply_reported = 0
                for request in apply_vector_requests:
                    target_layer = request['layer_spec']; req_key = (request['target_concept'], request['target_eff_num'], target_layer, request['op'], request['vec_name'], request['k'], request['metric'], request['original_line'])
                    description = f"'{request['target_concept']}'(L{request['target_eff_num']}) L{target_layer} {request['op']} '{request['vec_name']}' (L{target_layer})"
                    f.write(f"Neighbors for Vector: {description} - Top {request['k']} by {request['metric']} (Directive Line: {request['original_line']}):\n")
                    result_list = apply_vector_results.get(req_key)
                    if result_list is None:
                         if req_key in apply_vector_results: f.write("  - Result: Skipped (Error during calc/layer mismatch/neighbor search - check logs)\n\n")
                         else: f.write("  - Result: ERROR - Directive parsed but no result entry found (Internal error?).\n\n")
                         skipped_apply_reported += 1; continue
                    processed_apply_reported += 1; metric_used = request['metric']; dist_label = "Cosine Sim" if metric_used == 'cosine' else "Euclidean Dist"
                    if not result_list: f.write(f"  - No neighbors found (at Layer {target_layer}).\n\n"); continue
                    for neighbor_info, distance_or_sim in result_list: n_key = neighbor_info.get('target_word_key', 'N/A'); n_eff_num = neighbor_info.get('effective_prompt_num', 'N/A'); n_id = neighbor_info.get('id', 'N/A'); f.write(f"  - Neighbor: '{n_key}' (L{n_eff_num}) | {dist_label}: {distance_or_sim:.4f}"); f.write(f" | File ID: {n_id}\n") if level == 'full' else f.write("\n")
                    f.write("\n")
                f.write(f"Total #APPLY_VEC neighbor searches completed: {processed_apply_reported}\n"); f.write(f"Total #APPLY_VEC directives skipped or failed: {skipped_apply_reported}\n")
                total_reported_apply = processed_apply_reported + skipped_apply_reported; f.write(f"  (Warn: Mismatch reported({total_reported_apply}) vs parsed({num_apply_requested}))\n") if total_reported_apply != num_apply_requested else None; f.write("\n")
            elif num_apply_requested > 0: f.write(f"#APPLY_VEC directives parsed ({num_apply_requested}) but none yielded results.\n\n")


            # --- V9.0 Conceptual Drift Index (CDI) Section ---
            if args.calculate_cdi:
                 f.write("-" * (50 if level=='full' else 30) + "\n"); f.write(f" Conceptual Drift Index (CDI) Analysis Results\n"); f.write("-" * (50 if level=='full' else 30) + "\n\n")
                 f.write(f"Settings: Weights={args.cdi_weights}, VarIncluded={args.include_cdi_variance}, VarType='{args.cdi_variance_type}', Norm='{args.cdi_normalization}'\n\n")

                 # Filter results with valid CDI scores for sorting
                 valid_cdi_results = []
                 cdi_errors = 0
                 for res in results_data:
                     cdi_data = res.get('cdi_results')
                     if cdi_data and not cdi_data.get('error') and not np.isnan(cdi_data.get('cdi_score', np.nan)):
                         valid_cdi_results.append(res)
                     elif cdi_data and cdi_data.get('error'):
                         cdi_errors += 1

                 if cdi_errors > 0:
                      f.write(f"Note: CDI calculation failed for {cdi_errors} items (see console logs for details).\n\n")

                 if not valid_cdi_results:
                      f.write("No valid CDI scores were calculated.\n\n")
                 else:
                      # Sort by CDI score (descending)
                      # Handle potential NaNs in CDI score during sort just in case
                      valid_cdi_results.sort(key=lambda x: x['cdi_results'].get('cdi_score', -np.inf), reverse=True)

                      # --- Top K High-Drift Section ---
                      f.write(f"Top {min(args.top_cdi_k, len(valid_cdi_results))} Items by CDI Score:\n")
                      f.write("-" * 25 + "\n")
                      for i, res in enumerate(valid_cdi_results[:args.top_cdi_k]):
                          cdi_data = res['cdi_results']
                          eff_num = res.get('effective_prompt_num', 'N/A')
                          target = res.get('target_word_key', 'N/A')
                          cdi_s = cdi_data.get('cdi_score', np.nan)
                          drift_d = cdi_data.get('drift_direction', np.nan)
                          drift_p = cdi_data.get('drift_position_norm', np.nan)
                          drift_v = cdi_data.get('variance_term', np.nan)

                          f.write(f"{i+1}. L{eff_num} '{target}': CDI={cdi_s:.3f} ")
                          f.write(f"(Dir={drift_d:.3f}, Pos={drift_p:.3f}")
                          if args.include_cdi_variance:
                              f.write(f", Var={drift_v:.3f}")
                          f.write(")\n")
                      f.write("\n")

                      # --- Full CDI List (Only in Full Report) ---
                      if level == 'full':
                           f.write(f"Full CDI List (Sorted by CDI Score):\n")
                           f.write("-" * 25 + "\n")
                           for res in valid_cdi_results:
                               cdi_data = res['cdi_results']
                               eff_num = res.get('effective_prompt_num', 'N/A')
                               target = res.get('target_word_key', 'N/A')
                               file_id = res.get('id', 'N/A')
                               cdi_s = cdi_data.get('cdi_score', np.nan)
                               drift_d = cdi_data.get('drift_direction', np.nan)
                               drift_p = cdi_data.get('drift_position_norm', np.nan)
                               drift_v = cdi_data.get('variance_term', np.nan)

                               f.write(f"L{eff_num:<3} '{target:<15}' (ID: {file_id:<15}): CDI={cdi_s:<6.3f} ")
                               f.write(f"(Dir={drift_d:<6.3f}, Pos={drift_p:<6.3f}")
                               if args.include_cdi_variance:
                                   f.write(f", Var={drift_v:<6.3f}")
                               f.write(")\n")
                           f.write("\n")

            # --- Report Footer ---
            f.write("\n" + "="*50 + "\n"); f.write(f"          End of Report ({report_type} - {ANALYSIS_VERSION})\n"); f.write("="*50 + "\n") # V9.0 Update
        print(f"Successfully wrote {report_type} summary report.")
    except IOError as e: print(f"Error writing {report_type} summary report file '{report_path}': {e}")
    except Exception as e: print(f"An unexpected error occurred during {report_type} summary report generation: {e}"); traceback.print_exc()


# --- Clustering Visualization Function (V9.0 - Still uses Final Layer) ---
# [ Identical to V8.0 ]
def visualize_clusters(results_data, output_dir, plot_filename, n_layers_model):
    print("\nAttempting 2D cluster visualization (using FINAL layer activations)...")
    if not UMAP_AVAILABLE and not SKLEARN_AVAILABLE: print("  Skipping visualization: Required libraries not found."); return
    if not results_data: print("  Skipping visualization: No results data."); return
    target_layer_index = n_layers_model - 1; vectors = []; labels = []; hover_texts = []; valid_indices = []
    for i, res in enumerate(results_data):
        all_acts = res.get('all_layer_activations'); label = res.get('target_word_key'); eff_num = res.get('effective_prompt_num'); vec = None
        if all_acts is not None and isinstance(all_acts, np.ndarray) and all_acts.shape[0] == n_layers_model: vec = all_acts[target_layer_index, :]
        if vec is not None and isinstance(vec, np.ndarray) and vec.size > 0 and label is not None:
            if np.all(np.isfinite(vec)): vectors.append(vec); labels.append(label); hover_texts.append(f"'{label}' (L{eff_num}, ID:{res.get('id','N/A')})"); valid_indices.append(i)
    if len(vectors) < 2: print(f"  Skipping visualization: Need >= 2 valid finite final-layer vectors, found {len(vectors)}."); return
    X = np.array(vectors); print(f"  Prepared {X.shape[0]} final-layer vectors (dim {X.shape[1]}) for clustering."); method_used = "None"; X_reduced = None
    if UMAP_AVAILABLE:
        print("  Using UMAP...");
        try:
            n_neighbors_val = max(2, min(15, X.shape[0] - 1)); n_neighbors_val = max(1, X.shape[0] - 1) if X.shape[0] <= n_neighbors_val else n_neighbors_val
            if n_neighbors_val >= 2 : reducer = umap.UMAP(n_neighbors=n_neighbors_val, n_components=2, min_dist=0.1, random_state=42, metric='euclidean'); X_reduced = reducer.fit_transform(X); method_used = "UMAP";
            else: print(f"  Skipping UMAP: samples ({X.shape[0]}) < 2"); X_reduced = None
        except Exception as e: print(f"  UMAP Error: {e}. Fallback..."); X_reduced = None; traceback.print_exc()
    if X_reduced is None and SKLEARN_AVAILABLE:
        print("  UMAP failed/unavailable. Trying PCA + t-SNE...");
        try:
            n_pca_components = min(50, X.shape[0]-1, X.shape[1]); X_pca = PCA(n_components=n_pca_components).fit_transform(X) if n_pca_components > 1 else X
            perplexity_val = max(5, min(30, X_pca.shape[0] - 1)); perplexity_val = max(1, X_pca.shape[0] - 1) if X_pca.shape[0] <= perplexity_val else perplexity_val
            if perplexity_val >= 5 : tsne = TSNE(n_components=2, random_state=42, perplexity=perplexity_val, metric='euclidean'); X_reduced = tsne.fit_transform(X_pca); method_used = "PCA+tSNE";
            else: print(f"  Skipping t-SNE: samples ({X_pca.shape[0]}) < 5"); X_reduced = None
        except Exception as e: print(f"  PCA+tSNE Error: {e}."); X_reduced = None; traceback.print_exc()
    if X_reduced is None: print("  Skipping visualization: Dimensionality reduction failed."); return
    try: # Plotting
        plt.figure(figsize=(14, 11)); unique_labels = sorted(list(set(labels)))
        cmap1 = plt.colormaps.get_cmap('tab20'); cmap2 = plt.colormaps.get_cmap('tab20b'); cmap3 = plt.colormaps.get_cmap('Set3')
        colors_list = [cmap1(i) for i in range(cmap1.N)] + [cmap2(i) for i in range(cmap2.N)] + [cmap3(i) for i in range(cmap3.N)]; num_colors = len(colors_list);
        label_to_color = {label: colors_list[i % num_colors] for i, label in enumerate(unique_labels)}; plotted_labels = set()
        for i, label in enumerate(labels): color = label_to_color[label]; label_for_legend = label if label not in plotted_labels else None; plt.scatter(X_reduced[i, 0], X_reduced[i, 1], color=color, label=label_for_legend, alpha=0.7, s=40); plotted_labels.add(label) if label_for_legend else None
        handles, legend_labels = plt.gca().get_legend_handles_labels(); by_label = dict(zip(legend_labels, handles)); sorted_handles = [by_label[key] for key in sorted(by_label.keys())]; sorted_labels = sorted(by_label.keys())
        plt.legend(handles=sorted_handles, labels=sorted_labels, title="Concepts", bbox_to_anchor=(1.04, 1), loc='upper left', fontsize='small', title_fontsize='medium')
        plt.title(f'2D Visualization of FINAL Layer Activations ({method_used}) - {ANALYSIS_VERSION}'); plt.xlabel(f'{method_used} Comp 1'); plt.ylabel(f'{method_used} Comp 2'); plt.grid(True, linestyle='--', alpha=0.5); plt.tight_layout(rect=[0, 0, 0.85, 1])
        save_path = os.path.join(output_dir, plot_filename); plt.savefig(save_path); plt.close()
        print(f"  Cluster visualization (final layer) saved to: {save_path}")
    except Exception as e: print(f"  Error plotting/saving visualization: {e}"); traceback.print_exc()


# --- Main Execution Block (V9.0 Update) ---
if __name__ == "__main__":
    print(f"--- Unified Analysis Batch Script ({ANALYSIS_VERSION} - CDI Enabled) ---"); print(f"Timestamp: {TIMESTAMP}") # V9.0 Update
    # --- Setup ---
    main_output_dir = os.path.join(BASE_OUTPUT_DIR, ANALYSIS_VERSION_DIR)
    comparison_output_dir = os.path.join(main_output_dir, COMPARISON_SUBDIR)
    try: os.makedirs(main_output_dir, exist_ok=True); os.makedirs(comparison_output_dir, exist_ok=True); print(f"Main analysis directory: {main_output_dir}"); print(f"Comparison directory: {comparison_output_dir}")
    except OSError as e: print(f"FATAL: Error creating output directories: {e}"); exit(1)

    # --- Parse Input (V8/V9 compatible) ---
    experiments, comparison_requests, neighbor_requests, \
    vector_definitions_parsed, arithmetic_requests, apply_vector_requests = parse_input_file(INPUT_FILENAME)
    if experiments is None: exit(1)

    # --- Load Model ---
    print(f"\nLoading GPT-2 model (gpt2-small) on {DEVICE}...");
    try:
         model = HookedTransformer.from_pretrained("gpt2-small", device=DEVICE); model.eval();
         n_layers_model = model.cfg.n_layers; d_model_model = model.cfg.d_model
         print(f"Model loaded successfully ({n_layers_model} layers, d_model={d_model_model}).")
         if n_layers_model != N_LAYERS_GPT2_SMALL: print(f"Warning: Model layers ({n_layers_model}) != constant ({N_LAYERS_GPT2_SMALL}). Using model value.")
    except Exception as e: print(f"FATAL: Error loading model: {e}"); exit(1)


    # --- Run Batch Data Generation (Identical to V8.0) ---
    print(f"\nStarting batch processing for {len(experiments)} experiments...")
    results_data = []; skipped_experiments = []
    for i, exp in enumerate(experiments):
        prompt = exp['prompt']; target_word = exp['target_word']; prompt_id = exp['id']; eff_prompt_num = exp['effective_prompt_num']
        try:
            target_index, token_info = find_target_token_index(model, prompt, target_word)
            if target_index is None: print(f"  ---> Skip exp {eff_prompt_num}: target '{target_word}' not found."); skipped_experiments.append({**exp, 'reason': 'Tokenization Failure', 'details': f"Tokens: {token_info}"}); continue
            target_token_str = token_info;
            with torch.no_grad(): logits, cache = model.run_with_cache(prompt, prepend_bos=True)
            all_layer_activations = np.zeros((n_layers_model, d_model_model))
            for layer in range(n_layers_model):
                layer_activation = cache["resid_post", layer][0, target_index, :].cpu().numpy()
                if np.isnan(layer_activation).any(): print(f"    Warn: NaNs in activations Exp {eff_prompt_num}, L{layer}.")
                all_layer_activations[layer, :] = layer_activation
            token_dirname_sanitized = sanitize_filename(target_word.lower()); token_output_dir = os.path.join(main_output_dir, token_dirname_sanitized); os.makedirs(token_output_dir, exist_ok=True)
            prompt_identifier_sanitized = sanitize_filename(f"p{eff_prompt_num}_{target_word.lower()}"); base_filename = f"activations_{prompt_identifier_sanitized}"
            npy_filename = os.path.join(token_output_dir, f"{base_filename}.npy"); np.save(npy_filename, all_layer_activations);
            png_filepath = None
            if SAVE_INDIVIDUAL_HEATMAPS:
                heatmap_filename = f"heatmap_{prompt_identifier_sanitized}.png"; png_filepath = os.path.join(token_output_dir, heatmap_filename)
                try:
                    fig_ind, ax_ind = plt.subplots(figsize=(10, 6)); finite_vals = all_layer_activations[np.isfinite(all_layer_activations)]; vmin, vmax = (np.min(finite_vals), np.max(finite_vals)) if finite_vals.size > 0 else (-1, 1)
                    im_ind = ax_ind.imshow(all_layer_activations, aspect='auto', interpolation='nearest', cmap='viridis', vmin=vmin, vmax=vmax)
                    ax_ind.invert_yaxis(); fig_ind.colorbar(im_ind, ax=ax_ind, label='Activation Value'); ax_ind.set_xlabel(f'Neuron Idx (0-{d_model_model-1})'); ax_ind.set_ylabel(f'Layer (0 -> {n_layers_model-1})'); ax_ind.set_yticks(np.arange(n_layers_model)); ax_ind.set_yticklabels(np.arange(n_layers_model))
                    title_prompt_part = prompt[:40] + ('...' if len(prompt) > 40 else ''); ax_ind.set_title(f"Activations '{target_token_str}' ({prompt_id}/#{eff_prompt_num})\n\"{title_prompt_part}\"", fontsize=10)
                    plt.tight_layout(); plt.savefig(png_filepath); plt.close(fig_ind);
                except Exception as plot_err: print(f"  Warn: Error saving heatmap Exp {eff_prompt_num}: {plot_err}"); png_filepath = None
            final_layer_vector = np.asarray(all_layer_activations[-1, :]).copy()
            if np.isnan(final_layer_vector).any(): print(f"    Warn: Final layer vec Exp {eff_prompt_num} has NaNs.")
            results_data.append({
                'target_word_key': target_word.lower(), 'target_word_original': target_word, 'prompt': prompt, 'id': prompt_id, 'effective_prompt_num': eff_prompt_num,
                'token_str': target_token_str, 'token_index': target_index, 'all_layer_activations': all_layer_activations, 'final_layer_vector': final_layer_vector,
                'npy_path': npy_filename, 'png_path': png_filepath })
        except Exception as e: print(f"  ERROR processing prompt #{eff_prompt_num} ('{prompt}'): {e}"); print(f"  ---> Skip experiment."); skipped_experiments.append({**exp, 'reason': 'Processing Error', 'details': str(e)}); traceback.print_exc(); continue
    print("\nBatch data generation complete."); num_processed = len(results_data); print(f"Processed {num_processed}/{len(experiments)}. Skipped {len(skipped_experiments)}.")


    # --- Post-Processing Analysis (V9.0 adds CDI step) ---
    print("\n--- Post-Processing Analysis ---")
    if not results_data and not any([comparison_requests, neighbor_requests, vector_definitions_parsed, arithmetic_requests, apply_vector_requests]):
        print("No results generated and no analysis directives found. Exiting."); exit(0)
    elif not results_data:
         print("Warning: No experiment data generated. Analyses might fail or produce no results.")

    # --- Prepare Data Lookups (Identical to V8.0) ---
    results_by_num = {res['effective_prompt_num']: res for res in results_data}
    results_by_concept_first = {res['target_word_key']: res for res in results_data[::-1]}
    unique_concepts = sorted(list(results_by_concept_first.keys()))
    print(f"Found results for {len(unique_concepts)} unique target concepts (using first instance for concept lookups).")

    # --- Run Analyses (Identical to V8.0) ---
    concept_top_neurons = run_individual_concept_analysis(results_by_concept_first, TOP_N, n_layers_model) if results_data else {}
    comparison_results, diff_outputs, diff_neurons = run_comparative_analysis( comparison_requests, results_data, comparison_output_dir, TOP_N, n_layers_model ) if results_data else ({}, {}, {})
    neighbor_results = {}
    if neighbor_requests and results_data:
        print("\nRunning Neighborhood Analysis (NEIGHBORS)...")
        processed_count = 0; skipped_count = 0
        for request in neighbor_requests:
            layer_spec = request['layer_spec']
            req_key = (request['word_key'], request['eff_num'], request['k'], request['metric'], layer_spec)
            neighbors_list = find_neighbors( seed_word_key=request['word_key'], seed_eff_num=request['eff_num'], results_data=list(results_data), k=request['k'], metric=request['metric'], layer_spec=layer_spec, n_layers_model=n_layers_model)
            neighbor_results[req_key] = neighbors_list
            if neighbors_list is not None: processed_count += 1
            else: skipped_count +=1
        print(f"Neighborhood analysis complete. Processed {processed_count}/{len(neighbor_requests)}. Skipped: {skipped_count}")
    elif neighbor_requests: print("\nNeighborhood analysis skipped: No results data available.")
    else: print("\nNo NEIGHBORS analysis requested.")
    defined_vectors, arithmetic_results_data, apply_vector_results = run_vector_arithmetic( vector_definitions_parsed, arithmetic_requests, apply_vector_requests, results_data, results_by_num, results_by_concept_first, n_layers_model ) if results_data else ({},{},{})

    # --- V9.0 Run CDI Analysis ---
    if results_data:
        results_data = run_cdi_analysis(results_data, args, n_layers_model)
    else:
         print("\nConceptual Drift Index (CDI) calculation skipped: No results data.")


    # --- Generate Reports (V9.0 passes args for CDI reporting) ---
    summary_report_path_full = os.path.join(main_output_dir, SUMMARY_REPORT_FILENAME)
    summary_report_path_brief = os.path.join(main_output_dir, SUMMARY_REPORT_BRIEF_FILENAME)
    generate_summary_report(
        report_path=summary_report_path_full, level='full', timestamp=TIMESTAMP, input_filename=INPUT_FILENAME,
        main_output_dir=main_output_dir, results_data=results_data, experiments=experiments,
        skipped_experiments=skipped_experiments, unique_concepts=unique_concepts,
        comparison_requests=comparison_requests, neighbor_requests=neighbor_requests,
        vector_definitions_parsed=vector_definitions_parsed, arithmetic_requests=arithmetic_requests, apply_vector_requests=apply_vector_requests,
        concept_top_neurons=concept_top_neurons, comparison_results=comparison_results, neighbor_results=neighbor_results,
        defined_vectors=defined_vectors, arithmetic_results_data=arithmetic_results_data, apply_vector_results=apply_vector_results,
        difference_analysis_outputs=diff_outputs, difference_top_neurons=diff_neurons,
        comparison_output_dir=comparison_output_dir, top_n=TOP_N, n_layers_model=n_layers_model,
        args=args # V9.0 Pass args
    )
    generate_summary_report(
        report_path=summary_report_path_brief, level='brief', timestamp=TIMESTAMP, input_filename=INPUT_FILENAME,
        main_output_dir=main_output_dir, results_data=results_data, experiments=experiments,
        skipped_experiments=skipped_experiments, unique_concepts=unique_concepts,
        comparison_requests=comparison_requests, neighbor_requests=neighbor_requests,
        vector_definitions_parsed=vector_definitions_parsed, arithmetic_requests=arithmetic_requests, apply_vector_requests=apply_vector_requests,
        concept_top_neurons=concept_top_neurons, comparison_results=comparison_results, neighbor_results=neighbor_results,
        defined_vectors=defined_vectors, arithmetic_results_data=arithmetic_results_data, apply_vector_results=apply_vector_results,
        difference_analysis_outputs=diff_outputs, difference_top_neurons=diff_neurons,
        comparison_output_dir=comparison_output_dir, top_n=TOP_N, n_layers_model=n_layers_model,
        args=args # V9.0 Pass args
    )

    # --- (Optional) Cluster Visualization (V9.0 - Still Final Layer) ---
    if args.visualize_clusters:
        visualize_clusters(results_data, main_output_dir, plot_filename=CLUSTER_PLOT_FILENAME, n_layers_model=n_layers_model)
    else:
        print("\nCluster visualization skipped (uses final layer only).")

    # --- Final Summary (V9.0 Update) ---
    print(f"\nAnalysis complete ({ANALYSIS_VERSION}).")
    print(f"Full report generated: {summary_report_path_full}")
    print(f"Brief report generated: {summary_report_path_brief}")
    cluster_plot_path = os.path.join(main_output_dir, CLUSTER_PLOT_FILENAME)
    if args.visualize_clusters and os.path.exists(cluster_plot_path): print(f"Cluster plot (final layer) generated: {cluster_plot_path}")
    elif args.visualize_clusters: print(f"Cluster plot generation attempted but file may be missing: {cluster_plot_path}")

    # V9.0 Report CDI status
    if args.calculate_cdi:
         cdi_items_processed = len([res for res in results_data if 'cdi_results' in res])
         cdi_items_valid = len([res for res in results_data if res.get('cdi_results') and not res['cdi_results'].get('error')])
         print("\nConceptual Drift Index (CDI) Status:")
         print(f"  Calculation Requested: Yes")
         print(f"  Items Processed for CDI: {cdi_items_processed}/{len(results_data)}")
         print(f"  Valid CDI Scores Calculated: {cdi_items_valid}")
         if cdi_items_valid > 0:
             print(f"  Top {args.top_cdi_k} high-drift items listed in reports.")
         else:
              print(f"  No valid CDI scores generated (check logs for errors).")
    else:
         print("\nConceptual Drift Index (CDI) Status: Calculation not requested.")

    # Vector Arithmetic Status (Identical to V8.0)
    num_defs_succeeded = len(defined_vectors); num_arith_succeeded = len(arithmetic_results_data); num_apply_succeeded = len([res for res in apply_vector_results.values() if res is not None])
    print("\nVector Arithmetic Status:")
    print(f"  #DEFINE_VEC: Parsed={len(vector_definitions_parsed)}, Succeeded={num_defs_succeeded}")
    print(f"  #ARITHMETIC: Parsed={len(arithmetic_requests)}, Succeeded={num_arith_succeeded}")
    print(f"  #APPLY_VEC:  Parsed={len(apply_vector_requests)}, Succeeded (Search Ran)={num_apply_succeeded}")
    if len(vector_definitions_parsed) + len(arithmetic_requests) + len(apply_vector_requests) > 0 and \
       num_defs_succeeded + num_arith_succeeded + num_apply_succeeded < len(vector_definitions_parsed) + len(arithmetic_requests) + len(apply_vector_requests):
            print("  (Note: Some vector operations may have failed/skipped - check logs/reports)")

    print(f"\n{ANALYSIS_VERSION} adds Conceptual Drift Index (CDI). Use --calculate_cdi flag.")
    # --- End of V9.0 Updates ---

# --- END OF analyze_batch_v9.0.py ---