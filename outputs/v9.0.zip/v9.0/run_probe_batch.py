import json
from transformers import GPT2Tokenizer, GPT2LMHeadModel
import torch

# Load GPT-2 Small
model_name = "gpt2"
tokenizer = GPT2Tokenizer.from_pretrained(model_name)
model = GPT2LMHeadModel.from_pretrained(model_name)
model.eval()

# Use GPU if available
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)

# Configurable parameters
temperature = 0.0
top_p = 1.0
do_sample = False
max_new_tokens = 100

# Load prompts from file
with open("drift_probe_prompts_v1.txt", "r", encoding="utf-8") as f:
    prompts = [line.strip() for line in f if line.strip() and not line.startswith("#")]

# Run and log each prompt
output_path = "probe_outputs_v1.jsonl"
with open(output_path, "w", encoding="utf-8") as out_file:
    for prompt in prompts:
        inputs = tokenizer(prompt, return_tensors="pt").to(device)

        with torch.no_grad():
            outputs = model.generate(
                **inputs,
                max_new_tokens=max_new_tokens,
                temperature=temperature,
                top_p=top_p,
                do_sample=do_sample,
                pad_token_id=tokenizer.eos_token_id
            )

        response = tokenizer.decode(outputs[0], skip_special_tokens=True)
        result = {
            "prompt": prompt,
            "response": response
        }
        out_file.write(json.dumps(result) + "\n")
        print(f"[✓] {prompt[:60]}... → saved")
